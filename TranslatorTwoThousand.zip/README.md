# TranslatorTwoThousand
Language translator from English

# Language select:
![languageselect-entry-example](languageselect-entry-example.png)

# I tested using these inputs:
# text input mode: lets go dancing
![text-input-example](text-entry-example.png)

# url mode: https://pastebin.com/raw/xc498KV7
![url-input-example](url-entry-example.png)

# text file input: file.txt
![text file](textfile-entry-example.png)